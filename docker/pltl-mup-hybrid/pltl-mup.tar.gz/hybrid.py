#!/usr/bin/env python3

import sys
import os
import tempfile
import subprocess
import re

PLTLMUP = "pltl-mup/pltlmup"

TRPUC = "./trp"

UC_FILE = ".trp_core.trp"

MUP_UC_FILE = ".trp_core.pltl"


def keywordTranslate(text):
    text = re.sub("not", "~", text)
    text = re.sub("always", "G", text)
    text = re.sub("sometime", "F", text)
    text = re.sub("next", "X", text)
    text = re.sub("until", "U", text)
    text = re.sub("unless", "W", text)
    text = re.sub("next", "X", text)
    text = re.sub("\->", "=>", text)
    return text

def translateFile(infile, outfile):
    inf = open(infile, 'r')
    outf = open(outfile, 'w')

    for line in inf:
        ltlline = keywordTranslate(line).strip()
        if ltlline[-1] == '&':
            ltlline = ltlline[:-2].strip()
        outf.write(ltlline + "\n")

    inf.close()
    outf.close()

def main():
    filename = sys.argv[1]
    if not filename:
        print("No filename given!")
        sys.exit(1)

    # Create a temporary file for the TRP output

    # Run TRPUC with that input file
    p = subprocess.Popen("time {} -f ltl -s BFS -u simple -g ltl -w {} {}".format(TRPUC, UC_FILE, filename), shell=True)
    p.wait()

    print("[hybrid.py] TRP++UC execution finished. Starting PLTL-MUP")
    os.system("cat .trp_core.trp")

    # Translate the output from TRP into MUP syntax
    translateFile(UC_FILE, MUP_UC_FILE)

    # Feed the result in to MUP
    uc_file = open(MUP_UC_FILE, 'r') 


    p = subprocess.Popen("time {}".format(PLTLMUP), stdin=uc_file, shell=True)
    p.wait()

    print("[hybrid.py] PLTL-MUP execution finished")
    #Clean up


if __name__ == "__main__":
    main()

