
module P = PLTLFormula

open MiscSolver
open PLTLMisc
open Buddy


(** Lookup table from formula integer to corresponding BDD
 *)
let arrayBDD = ref (Array.make 0 bdd_true)

let formulaMap = ref (Array.make 0 0)

let labelBDD = ref (Array.make 0 bdd_true)

let labelVars = ref (Array.make 0 0)

let formulaCount = ref 0

let bddVarCount = ref 0



let initBDD initial =
  let rec mkbdd i =
    if !arrayBDD.(i) = bdd_true then
      match !arrayType.(i) with
	| 0 -> (* TRUE *) !arrayBDD.(i) <- bdd_true
	| 1 -> (* FALSE *) !arrayBDD.(i) <- bdd_false
	| 2    (* AP _ *)
	| 4 -> (* X *)
	    let v' = bdd_newvar() in
	    let v  = bdd_newvar() in
	    let vi = int_of_var v in
	    let vi' = int_of_var v' in
	    ignore (bdd_intaddvarblock vi' vi 0);
			  !arrayBDD.(i) <- bdd_pos v'
			  (*; print_endline ("BDD " ^ (string_of_int vi') ^ "\t" ^ (P.exportFormula !arrayFormula.(i)))*)
	| 3 -> (* NOT _ *)
	    let f1 = mkbdd (!arrayNeg.(i)) in
	    !arrayBDD.(i) <- bdd_not f1
	| 5 -> (* OR *)
	    let f1 = mkbdd (!arrayDest1.(i)) in
	    let f2 = mkbdd (!arrayDest2.(i)) in
	    !arrayBDD.(i) <- bdd_or f1 f2
	| 6 -> (* AND *)
	    let f1 = mkbdd (!arrayDest1.(i)) in
	    let f2 = mkbdd (!arrayDest2.(i)) in
	    !arrayBDD.(i) <- bdd_and f1 f2
	| 7 -> (* UN *)
	    let f1 = mkbdd (!arrayDest1.(i)) in
	    let f2 = mkbdd (!arrayDest2.(i)) in
	    !arrayBDD.(i) <- bdd_or f1 f2
	| 8  ->  (* BF *)
	    let f1 = mkbdd (!arrayDest1.(i)) in
	    let f2 = mkbdd (!arrayDest2.(i)) in
	    !arrayBDD.(i) <- bdd_and f1 f2
	| _ -> raise (P.PLTLException "Not in NNF, needs a rethink")
    else ();
	!arrayBDD.(i)
  in
	arrayBDD := (Array.make !nrFormulae bdd_true);

	for i = !lposEX to !hposEX do
	  ignore (mkbdd i); (* <X g> *)
	  ignore (mkbdd !arrayDest1.(i)); (* g *) 
	done;
	ignore (mkbdd initial)

(* Maps individual input formulae to their internal identifier.
 * Base case: When we are on the final formula, always add it to the mapping
 * Step case: When we are on an and, always add left to the mapping and recurse right 
 *)
let initFormulaMap initial =
  let rec makemap i position = 
    if position = (!formulaCount - 1) then
      (* Base case *)
      let _ = !formulaMap.(position) <- i in
      (* Print out the corresponding subformula *) 
	let _ = print_endline (string_of_int !arrayType.(!formulaMap.(position))) in
	let _ = Printf.printf "Formula %d: %s\n" position (P.exportFormula !arrayFormula.(!formulaMap.(position))) in
      ()
    else
      if !arrayType.(i) == 6 then (* Must be an and *)
	(* Recurse down the right *)
	let _ = makemap (!arrayDest2.(i)) (position + 1) in

	(* The left is the formula we want *)
	let _ = !formulaMap.(position) <- !arrayDest1.(i) in
	(* Print out the corresponding subformula *) 
	let _ = print_endline (string_of_int !arrayType.(!formulaMap.(position))) in
	let _ = Printf.printf "Formula %d: %s\n" position (P.exportFormula !arrayFormula.(!formulaMap.(position))) in
	()
      else
	raise (P.PLTLException "Couldn't find and, something wrong with NNF")
    in
    formulaMap := (Array.make !formulaCount 0);
    makemap initial 0

(* Fetches the BDD for an individual input formula *)
let formulaBDD i =
  let nnfID = !formulaMap.(i) in
  !arrayBDD.(nnfID)

  


let _ =

  (* Parse command line to determine what options to use *)

  let preemptiveCheck = ref false in
  let assumeGs = ref true in
  let compact = ref false in
  let simultaneous = ref false in
  let verbose = ref 2 in
  let silent = ref false in
  let nodelimit = ref (false,1000) in
  let echo = ref true in

  let speclist = [
    (* ("-nopreempt", Arg.Unit (fun () -> preemptiveCheck := false), "Disable
     * preemptive checks for unsatisfiability");*)
    ("-noassumeg", Arg.Unit (fun () -> assumeGs := false), "Disable explicitly assuming global constraints");
  ("-simultaneous", Arg.Unit (fun () -> simultaneous := true), "Perform updates to the state together, rather than sequentially");
  (*("-nocompact", Arg.Unit (fun () -> compact := false), "Disable formula rewriting as a preprocessing step");*)
  ("-verbose", Arg.Unit (fun () -> incr verbose), "Enable verbose output");
  ("-silent", Arg.Unit (fun () -> silent := true), "Disable garbage collection printouts");
  ("-nodelimit", Arg.Int (fun maxn -> nodelimit := (true, maxn)), "Limit the number of BDD nodes created, approximate");
  ("-echo", Arg.Unit (fun () -> echo := true), "Print out the input formula after optimisations")
] in

  let _ = Arg.parse speclist (fun _ -> (* silently ignore *) ()) "" in


  let preemptiveCheck = !preemptiveCheck in
  let assumeGs = !assumeGs in

  let infoMesg i =
    if i <= !verbose then print_endline
  else fun _ -> ()
  in

  let rewrite =
    if !compact then P.compactAW
	else fun f -> f
	in

  let _ = infoMesg 1 ("Verbose level " ^ (string_of_int !verbose)) in

  (*let input = read_line () in*)

      let startTime = Unix.gettimeofday() in
      (* Configure BDD package *)
      let _ = 
	let (set,limit) = !nodelimit in
	bdd_init ~nodenum:limit ();
	  if set then
	    ignore (bdd_setmaxnodenum (max limit ((bdd_getallocnum ())+1)));
	  if !silent then
	    bdd_silenceGbc ()
	in
  let _ = 
    if bdd_setmaxincrease 50000000 < 0 
	|| bdd_setcacheratio 64 < 0 then begin 
	  print_endline "Error setting maxincrease or cacheratio!";
		exit(-1)
	end
      in


  let initTime = Unix.gettimeofday() in
  let _ = infoMesg 1 ("Initialised BDD package in " ^ (string_of_float (initTime -. startTime))) in

  (* Parse and preprocess formula *)
  (*let f = P.importFormula input in *)
      let rec parseform () = 
	try
	  let input = read_line () in
	  let _ = incr formulaCount in
	  P.AND (P.importFormula input, parseform ())
	with
      End_of_file -> P.TRUE
	  in
  let f = parseform () in
  let f = rewrite f in
  let _ = if !echo then print_endline (P.exportFormula f) in
  let (f,nnf) = PLTLMisc.ppFormula f PLTLMisc.ranking PLTLMisc.noty in

  let _ = if !echo then print_endline (P.exportFormula f) in
  let _ = infoMesg 1 ("Parsed formula in " ^ (string_of_float ((Unix.gettimeofday()) -. initTime))) in

  (* Check for pure propositional; send to SATsolver?*)
  (* Map the input formulae to nnf numbers *)
  let _ = initFormulaMap nnf in
  let _ = initBDD nnf in 
  (* Check for early termination conditions *)
  let _ = 
    if !arrayBDD.(nnf) = bdd_false then
      begin
	infoMesg 1 "False immediately! (Pass to MUP?)"; (* TODO *)
		print_endline "Unsatisfiable";
		bdd_done ();
		exit 0
	end
    else if !hposEX < 0 then
      begin
	infoMesg 1 "Purely Propositional";
		print_endline "Satisfiable";
		bdd_done ();
		exit 0
      end
  in

  let nBDDvars = bdd_varnum() in
  let _ = infoMesg 1 ("Number of BDD variables+clones: " ^ (string_of_int nBDDvars)) in
  (* If f ~ bdd[i] then f' ~ bdd[i+1]*)
  let pairmap = bdd_newpair() in
  let vdash = 
    let vars =
      let rec fn acc i =
	if i < 0 then acc
		else fn ((2*i+1)::acc) (pred i)
  in
		fn [] (pred (nBDDvars/2))
      in
	  bdd_makeset vars
    in
	(*	  bdd_autoreorder ~strategy:Win2ite ();*)
  let _ =
    for i = 0 to (nBDDvars/2-1) do
      if bdd_setpair pairmap (2*i) (2*i + 1) != 0 then begin
	print_endline "Error constructing pair map!";
		exit (-1)
      end
	done;
  in

  let arrayBDDdash = Array.copy !arrayBDD in
  let _ =
    for i = 0 to !nrFormulae-1 do
      arrayBDDdash.(i) <- bdd_replace !arrayBDD.(i) pairmap
    done
  in

	(* Construct the BDD representing the (restriction on the) modal relation *)

  let _ = infoMesg 1 "Creating bddR..." in
  let startRTime = Unix.gettimeofday () in

  let bddR =
    let rec fn acc i =
      if i < !lposEX then acc
	  else begin
	    (* <X g> <=> g' *)
	    let exg = !arrayBDD.(i) in
	    let g = arrayBDDdash.(!arrayDest1.(i)) in
	    let b = bdd_biimp exg g in
	    fn (b::acc) (pred i)
      end
	    in
	let l = (fn [] !hposEX) in
	(* let _ = bdd_reorder ~strategy:Win2ite () in *)
  if l = [] then
    bdd_true
      else
	bdd_bigand l
  in

  let bddRTime = (Unix.gettimeofday ()) -. startRTime in
  let _ = infoMesg 1 ("Defined bddR in " ^ (string_of_float bddRTime)) in


  (* The condition that a state must have some successor *)
  let bddSucc s =
    bdd_appex bddR (bdd_replace s pairmap) 0 vdash
	(*bdd_exist (bdd_and bddR (bdd_replace s pairmap)) vdash*)
  in

	(* The condition that each existential must have a witness*)
  let bddLC1 s =
    let sdash = bdd_replace s pairmap in
    let rs = bdd_and sdash bddR in
    let rec fn acc i =
      if i < !lposEX then acc
	  else begin
	    (* ~<X g> v exists( S(V') ^ R(V,V') ^ g' *)
	    let exist = bdd_appex arrayBDDdash.(!arrayDest1.(i)) rs 0 vdash in
	    let b = bdd_imp !arrayBDD.(i) exist in
	    fn (b::acc) (pred i)
	  end
	    in
	let l = (fn [] !hposEX) in
	if l = [] then bdd_true
	  else bdd_bigand l
	in

	(* Find the set of worlds which satisfy (g U h) *)
  let fragun rs i =
    let h = !arrayBDD.(!arrayDest1.(i)) in
    let g = !arrayBDD.(!arrayDest1.(!arrayDest2.(i))) in
    let iter = ref 0 in
    let rec fix z =
      incr iter;
	  infoMesg 3 ("Intermediate frageu: " ^ (string_of_int !iter));
	  let inner = bdd_replace z pairmap in
	  let exist = bdd_appex inner rs 0 vdash in
	  (*	  let exist = bdd_exist (bdd_and inner bddR) vdash in*)
    let znew = bdd_or h (bdd_and g exist) in
    if znew = z then z
		else fix znew
    in
	let ret = fix h in
	infoMesg 2 ("frageu: " ^ (P.exportFormula (!arrayFormula.(i))) ^ " -- " ^ string_of_int !iter);
	  ret
	in

	(* The worlds which claim to satisfy an eventuality must actually do so *)
  let bddUn s =
    let lst =
      let rs = bdd_and (bdd_replace s pairmap) bddR in
      let rec fn acc i =
	if i < !lposEX then acc
		else begin
		  if !arrayType.(!arrayDest1.(i)) = 7 (* UN *) then begin
		    infoMesg 3 ("UN " ^ (P.exportFormula !arrayFormula.(!arrayDest1.(i))));
			let eu = !arrayDest1.(i) in
			let exeu = !arrayBDD.(i) in
			let g = !arrayBDD.(!arrayDest1.(!arrayDest2.(eu))) in
			let frag = fragun rs eu in
			fn ((bdd_imp (bdd_and exeu g) frag)::acc) (pred i)
	  end
	else fn acc (pred i)
		  end
			in
		fn [] !hposEX
      in
	  if lst = [] then bdd_true
	  else bdd_bigand lst
    in


  (* Try to restrict the initial state as much as possible *)
  (* e.g. if a formula G p holds, then p must hold everywhere *)
  let initialGuess i =
    let rec internf acc i =
      match !arrayType.(i) with
		| 6 (* AND *) -> internf (internf acc !arrayDest1.(i)) !arrayDest2.(i)
		| 8 (* BF *) -> 
		    if !arrayDest1.(!arrayDest2.(i)) = !bsfalse then
		      internf (!arrayBDD.(!arrayDest1.(i))::acc) !arrayDest1.(i)
	  else acc
		| _ -> acc
  in
	  if assumeGs then bdd_bigand (internf [bdd_true] i)
	  else bdd_true
    in

  let stateBDD =
    infoMesg 1 "Starting state calculation...";
	let iter = ref 0 in

	(* Two possible ways of performing the fixpoint computation *)
	(* I believe that sequential works better than simultaneous *)
	let rec fixsequence s =
	  if preemptiveCheck && bdd_and s !arrayBDD.(nnf) = bdd_false then bdd_false
	  else begin
	    incr iter;
		infoMesg 3 ("GFP intermediate: " ^ (string_of_int !iter));
		let snew = s in
		let _ = infoMesg 2 "Succ..." in
		let snew = bdd_and snew (bddSucc snew) in
		let _ = infoMesg 2 "LC1..." in
		let snew = bdd_and snew (bddLC1 snew) in
		let _ = infoMesg 2 "UN..." in
		let snew = bdd_and snew (bddUn snew) in
		if snew = s then s
		  else fixsequence snew
		end
		in
	let rec fixsimultaneous s =
	  if preemptiveCheck && bdd_and s !arrayBDD.(nnf) = bdd_false then bdd_false
	  else begin
	    incr iter;
		infoMesg 3 ("GFP intermediate: " ^ (string_of_int !iter));
		let _ = infoMesg 2 "Succ..." in
		let succ = (bddSucc s) in
		let _ = infoMesg 2 "LC1..." in
		let lc1 = (bddLC1 s) in
		let _ = infoMesg 2 "Un..." in
		let un = (bddUn s) in
		let snew = bdd_bigand [s;succ;lc1;un] in
		if snew = s then s
		  else fixsimultaneous snew
	  end
		in
	let fix = 
	  if !simultaneous then
	    fixsimultaneous
		else
		  fixsequence
	in
	let ret = fix (initialGuess nnf) in
	infoMesg 1 ("GFP: " ^ string_of_int !iter);
	  ret
	in

  let _ = if stateBDD = bdd_false then
    print_endline "StateBDD is false?"
  in

  let _ = if (bdd_and stateBDD (formulaBDD 0)) = bdd_false then
    print_endline "Conjunction with first formula is false"
  in

  (* print_endline (P.exportFormula !arrayFormula.(nnf)); *)
  (* bdd_fprintdot stdout (!arrayBDD.(nnf)); *)

  let answer = bdd_and stateBDD !arrayBDD.(nnf) in

    let elapsed = (Unix.gettimeofday()) -. startTime in
  let _ = infoMesg 1 ("Time elapsed: " ^ (string_of_float elapsed)) in


  if answer = bdd_false then
    print_endline "Unsatisfiable"
  else
    print_endline "Satisfiable";
  
  let test = bdd_bigand [stateBDD; formulaBDD 0; formulaBDD 2; formulaBDD 3] in

  let _ = Printf.printf "Test is unsatisfiable: %B\n" (test = bdd_false) in


    bdd_done()
