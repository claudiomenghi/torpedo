(** PLTL theorem prover, with minimisation for unsatisfiable inputs
 *
 * Original author: Jimmy Thompson
 * PLTL-MUP author: Tim Sergeant, 2013
 * Sections that I've changed have been clearly marked
 *)


module P = PLTLFormula

open MiscSolver
open PLTLMisc
open Buddy


(** Lookup table from formula integer to corresponding BDD
 *)
let arrayBDD = ref (Array.make 0 bdd_true)

(* Additional variables for PLTL-MUP *)

(** Map input formula numbers to nnf ids *)
let formulaMap = ref (Array.make 0 0)

(** Map nnf ids to input formulae *)
let nnfIdMap = ref (Hashtbl.create 1)

(** Array containing the label BDDs *)
let labelBDD = ref (Array.make 0 bdd_true)

(** Array mapping label variable numbers (ie, y_i) to BDD variables *)
let labelVars = ref (Array.make 0 0)

(** Total number of input formulae *)
let formulaCount = ref 0

(** Total number of input formulae, excluding hard constraints *)
let softFormulaCount = ref 0



let initBDD initial =
  let rec mkbdd i =
    if !arrayBDD.(i) = bdd_true then
      match !arrayType.(i) with
	| 0 -> (* TRUE *) !arrayBDD.(i) <- bdd_true
	| 1 -> (* FALSE *) !arrayBDD.(i) <- bdd_false
	| 2    (* AP _ *)
	| 4 -> (* X *)
	    let v' = bdd_newvar() in
	    let v  = bdd_newvar() in
	    let vi = int_of_var v in
	    let vi' = int_of_var v' in
	    ignore (bdd_intaddvarblock vi' vi 0);
			  !arrayBDD.(i) <- bdd_pos v'
			  (*; print_endline ("BDD " ^ (string_of_int vi') ^ "\t" ^ (P.exportFormula !arrayFormula.(i)))*)
	| 3 -> (* NOT _ *)
	    let f1 = mkbdd (!arrayNeg.(i)) in
	    !arrayBDD.(i) <- bdd_not f1
	| 5 -> (* OR *)
	    let f1 = mkbdd (!arrayDest1.(i)) in
	    let f2 = mkbdd (!arrayDest2.(i)) in
	    !arrayBDD.(i) <- bdd_or f1 f2
	| 6 -> (* AND *)
	    let f1 = mkbdd (!arrayDest1.(i)) in
	    let f2 = mkbdd (!arrayDest2.(i)) in
	    !arrayBDD.(i) <- bdd_and f1 f2
	| 7 -> (* UN *)
	    let f1 = mkbdd (!arrayDest1.(i)) in
	    let f2 = mkbdd (!arrayDest2.(i)) in
	    !arrayBDD.(i) <- bdd_or f1 f2
	| 8  ->  (* BF *)
	    let f1 = mkbdd (!arrayDest1.(i)) in
	    let f2 = mkbdd (!arrayDest2.(i)) in
	    !arrayBDD.(i) <- bdd_and f1 f2
	| _ -> raise (P.PLTLException "Not in NNF, needs a rethink")
    else ();
	!arrayBDD.(i)
  in
	arrayBDD := (Array.make !nrFormulae bdd_true);

	for i = !lposEX to !hposEX do
	  ignore (mkbdd i); (* <X g> *)
	  ignore (mkbdd !arrayDest1.(i)); (* g *) 
	done;
	ignore (mkbdd initial)

(* Begin PLTL-MUP specific code *)

(* Maps individual input formulae to their internal identifier.
 * Base case: When we are on the final formula, always add it to the mapping
 * Step case: When we are on an and, always add left to the mapping and recurse right 
 *)
let initFormulaMap initial =
  let rec makemap i position = 
    if position = (!formulaCount - 1) then
      (* Base case *)
      let _ = !formulaMap.(position) <- i in
      let _ = Printf.printf "Formula %d: %s\n" position (P.exportFormula !arrayFormula.(!formulaMap.(position))) in
      ()
    else
      if !arrayType.(i) == 6 then (* Must be an and *)
	(* The left is the formula we want *)
	let _ = !formulaMap.(position) <- !arrayDest1.(i) in
	(* Print out the corresponding subformula *)
	let _ = Printf.printf "Formula %d: %s\n" position (P.exportFormula !arrayFormula.(!formulaMap.(position))) in
	(* Recurse down the right *)
	makemap (!arrayDest2.(i)) (position + 1)

    else
      raise (P.PLTLException "Couldn't find and, something wrong with NNF")
  in
  (** Records the NNF id of each input formula.
   * Allows us to take an nnf later on and determine
   * which formula it belongs to
   *)
  let rec initNnfMap pos =
    if pos = !formulaCount then
      ()
    else
      let _ = Hashtbl.add !nnfIdMap !formulaMap.(pos) pos in
      initNnfMap (pos + 1)
  in

  formulaMap := (Array.make !formulaCount 0);
  nnfIdMap := (Hashtbl.create 0);
  let _ = makemap initial 0 in
  initNnfMap 0


(** Prints a list of formulae with positions
 * @param results List of nnf IDs
 *)
let printMinunsat results =
  let rec printHelper xs pos =
    match xs with
    | [] -> ()
    | r::rs -> let formulaId = !formulaMap.(pos) in
	      let _ = if r then 
		Printf.printf "%d: %s\n" pos (P.exportFormula !arrayFormula.(formulaId)) in
	      printHelper rs (pos + 1)
  in
  printHelper results 0

(** Helper function for reading in the hard constraints file *)
let readAllLines fileName =
  let inChannel = open_in fileName in
  let rec readRec lines =
    try
      Scanf.fscanf inChannel "%[^\n]\n" (fun x -> readRec (x::lines))
    with End_of_file ->
      lines
  in
  let lines = readRec [] in
  let _ = close_in_noerr inChannel in
  List.rev(lines)

(* Fetches the BDD for an individual input formula *)
let formulaBDD i =
  let nnfID = !formulaMap.(i) in
  !arrayBDD.(nnfID)

(* Determines whether a given Nnf id corresponds to a hard constraint *)
let hardConstraint nnfId =
  try
    let formulaId = Hashtbl.find !
    
    (* Additional variables for PLTL-MUP *)nnfIdMap nnfId in
    (formulaId >= !softFormulaCount)
  with Not_found ->
    false

(* Try to restrict the initial state as much as possible *)
(* e.g. if a formula G p holds, then p must hold everywhere.
 * However, we only perform this optimisation for hard constraints *)
(* Takes a NNF id, returns a BDD *)
let assumeGlobal i =
  let rec internf acc i insideHC =
      let nowInsideHC = 
	if insideHC then true
	else hardConstraint i
      in
      match !arrayType.(i) with
		| 6 (* AND *) -> internf (internf acc !arrayDest1.(i) nowInsideHC) !arrayDest2.(i) nowInsideHC
		| 8 (* BF *) -> 
		      if nowInsideHC && !arrayDest1.(!arrayDest2.(i)) = !bsfalse then
		      internf (!arrayBDD.(!arrayDest1.(i))::acc) !arrayDest1.(i) nowInsideHC
	  else acc
		| _ -> acc
  in
  bdd_bigand (internf [bdd_true] i false)

(** Creates a set of all the non-label variables. This is done by
 * and-ing together all of the variables created by the theorem 
 * prover (before the minimisation begins)
 *)
let makeNonLabelSet () = 
  let rec nonLabelHelper pos =
    if pos = -1 then
      bdd_true
    else
      bdd_and (bdd_pos pos) (nonLabelHelper (pos - 1))
  in
  nonLabelHelper ((bdd_varnum ()) - 1)



(* Creates the label variables and a tag BDD for each formula *)
let makeLabels () =
  let labelCount = int_of_float ( ceil ( log(float_of_int(!softFormulaCount + 1)) /. log(2.) )) in
  (* Create label variables *)
  let rec makeLabelVars pos = 
    if pos = labelCount then
      ()
    else
      let _ = !labelVars.(pos) <- bdd_newvar () in
      makeLabelVars (pos + 1)

  in

  (** Create a single label BDD using a simple binary conversion
   * on the ID
   *)
  let rec makeSingleLabel id pos acc =
    if pos = labelCount then
      acc
    else
      let rem = id mod 2 in
      let var = bdd_pos(!labelVars.(pos)) in
      let var =
	if rem = 0 then
	  bdd_not var
	else
	  var
      in
      makeSingleLabel (id / 2) (pos + 1) (bdd_and acc var)

  in
  (** Create a label BDD for every input formula (excluding hard constraints) *)
  let rec labelHelper pos =
    if pos = !softFormulaCount then
      () 
    else
      let _ = !labelBDD.(pos) <- makeSingleLabel pos 0 bdd_true in
      labelHelper (pos + 1)
  in
  labelVars := (Array.make labelCount 0);
  labelBDD := (Array.make !softFormulaCount bdd_false);
  makeLabelVars 0;
  labelHelper 0


(* Given a fixpoint, computes a minimal unsatisfiable subset of formulae
 * for the input.
 *
 * Returns a list of booleans, where the ith entry is true if the corresponding
 * element of the input set is included in the MU set.
 *)
let minUnsat w_f =
  Printf.printf "\n\nBeginning reduction to minunsat\n";
  (*Printf.printf("Formula count: %d soft (%d total)\n") !softFormulaCount !formulaCount;*)
  Printf.printf("Formula count: %d\n") !softFormulaCount;

  let unsatStartTime = Unix.gettimeofday () in
  let nonLabelVars = makeNonLabelSet () in
  let _ = makeLabels () in

  (* Makes starting state with all formulae enabled *)
  let rec startInclude n =
    if n = 0 then
      []
    else
      true::(startInclude (n-1))
  in

  (** Creates a BDD representing the set of hard contstraints *)
  let hardConstraints =
    let rec hcHelper pos =
      if pos = !formulaCount then
	[]
      else
	(assumeGlobal !formulaMap.(pos))::(hcHelper (pos + 1))
    in
    let constraints = hcHelper !softFormulaCount in
    if (List.length constraints) = 0 then bdd_true
    else bdd_bigand constraints 
  in

  (* Create the current state BDD based on an input of which BDDs are currently
   * turned on. Ie, an input of [true; true; true] will concatenate all 3 formula
   * BDDs (along with their labels), while [true; false; true] will turn off formula
   * one.
   *
   * Returns a BDD
   *)
  let createState included =
    let rec stateHelper inc pos = match inc with
      [] -> []
      | false::xs -> stateHelper xs (pos + 1)
      | true::xs -> let form = (bdd_or (formulaBDD pos) (!labelBDD.(pos))) in
      form::(stateHelper xs (pos + 1))
    in
    bdd_and w_f (bdd_and hardConstraints (bdd_bigand (stateHelper included 0)))
  in

  let countFormula blist =
    List.length (List.filter (fun b -> b) blist)
  in

  (* Finds a formula which can be safely removed from the current stateBDD, and
   * removes it. *)
  let removeFormula state included =
    let rec removeFormula' state included pos =
      match included with
	  [] -> []
      | false::xs -> false::(removeFormula' state xs (pos + 1))
      | true::xs -> let restricted = bdd_restrict state !labelBDD.(pos) in
      (* If the input remains unsatisfiable when we remove
       * this clause, remove that formula *)
      if restricted = bdd_false then
	let _ = Printf.printf("Removed formula %d\n") pos in
	false::xs
      else
	true::(removeFormula' state xs (pos + 1))
      in
      removeFormula' state included 0
  in

  let labelSet = bdd_makeset(Array.to_list !labelVars) in

  (* Minimises the current included set of formula to be minunsat.
   * Checks whether the set is currently minunsat. If not, finds
   * a formula to remove and then calls itself recursively without
   * that formula
   *)
  let rec doMinimise included =
    let state = createState included in
    (** We currently don't see any performance issues with quantifying all at once (rather
     * than attempting early quantification). This could be an avenue for future
     * optimisations
     *)
    let exist_state = bdd_exist state nonLabelVars in
    let count = bdd_satcountset (exist_state) labelSet in

    if count = (countFormula included) then
      included
    else
      let removed = removeFormula exist_state included in
      if removed = included then
	let _ = Printf.printf("Could not find a formula to remove.\n") in
	included
      else
	doMinimise removed
  in

  let result = doMinimise (startInclude !softFormulaCount) in
  let unsatEndTime = Unix.gettimeofday () in
  let _ = Printf.printf "Minimisation time elapsed: %s\n" (string_of_float (unsatEndTime -. unsatStartTime)) in
  result 

(** End of MUP-specific code *)


let _ =

  (* Parse command line to determine what options to use *)

  let preemptiveCheck = ref false in
  let assumeGs = ref true in
  let compact = ref false in
  let simultaneous = ref false in
  let verbose = ref 1 in
  let silent = ref false in
  let nodelimit = ref (false,1000) in
  let echo = ref true in
  let cacheratio = ref 16 in
  let minimise = ref true in

  let hcFile = ref "" in

  let speclist = [
    (* ("-nopreempt", Arg.Unit (fun () -> preemptiveCheck := false), "Disable
     * preemptive checks for unsatisfiability");*)
    (*("-noassumeg", Arg.Unit (fun () -> assumeGs := false), "Disable explicitly assuming global constraints");*)
  ("-simultaneous", Arg.Unit (fun () -> simultaneous := true), "Perform updates to the state together, rather than sequentially");
  (*("-nocompact", Arg.Unit (fun () -> compact := false), "Disable formula rewriting as a preprocessing step");*)
  ("-verbose", Arg.Unit (fun () -> incr verbose), "Enable verbose output");
  ("-silent", Arg.Unit (fun () -> silent := true), "Disable garbage collection printouts");
  ("-nodelimit", Arg.Int (fun maxn -> nodelimit := (true, maxn)), "Limit the number of BDD nodes created, approximate");
  ("-cacheratio", Arg.Int (fun cr -> cacheratio := cr), "Change the size of the BDD cache (smaller gives a larger cache)");
  ("-echo", Arg.Unit (fun () -> echo := true), "Print out the input formula after optimisations");
  ("-hc", Arg.String (fun hcArg -> hcFile := hcArg), "Load hard constraints from a file"); 
  ("-nomup", Arg.Unit (fun () -> minimise := false), "Disable minimisation of unsatisfiable inputs")
] in

  let _ = Arg.parse speclist (fun _ -> (* silently ignore *) ()) "" in


  let preemptiveCheck = !preemptiveCheck in
  let assumeGs = !assumeGs in

  let infoMesg i =
    if i <= !verbose then print_endline
  else fun _ -> ()
  in

  let rewrite =
    if !compact then P.compactAW
	else fun f -> f
	in

  let _ = infoMesg 1 ("Verbose level " ^ (string_of_int !verbose)) in

  (*let input = read_line () in*)

      let startTime = Unix.gettimeofday() in
      (* Configure BDD package *)
      let _ = 
	let (set,limit) = !nodelimit in
	bdd_init ~nodenum:limit ();
	  if set then
	    ignore (bdd_setmaxnodenum (max limit ((bdd_getallocnum ())+1)));
	  if !silent then
	    bdd_silenceGbc ()
	in
  let _ = 
    if bdd_setmaxincrease 50000000 < 0 
	|| bdd_setcacheratio !cacheratio < 0 then begin 
	  print_endline "Error setting maxincrease or cacheratio!";
		exit(-1)
	end
      in


  let initTime = Unix.gettimeofday() in
  let _ = infoMesg 1 ("Initialised BDD package in " ^ (string_of_float (initTime -. startTime))) in

  (* Parse and preprocess formula from stdin *)
  (* Additions for PLTL-MUP to allow for multiple
   * inputs and hard constraints
   *)
  let rec parseForm initForm =
    (* Base case: initForm *)
    (* Step case: Input & initForm *)
    try
      let input = read_line () in
      let form = P.importFormula input in

      let result = parseForm initForm in

      let _ = incr formulaCount in
      let _ = incr softFormulaCount in

      P.AND (form, result)
    with
      End_of_file -> initForm
  in
  
  let parseHC initForm =
    let lines = readAllLines !hcFile in
    let rec parseHCHelper form lineList =
      match lineList with
	[] -> form
      | f::fs -> let _ = incr formulaCount in
		parseHCHelper (P.AND (P.importFormula f, form)) fs
    in
    parseHCHelper initForm lines
  in
  
  
  let f =
    if !hcFile = "" then
      P.TRUE
    else
      parseHC P.TRUE
  in
  let f = parseForm f in
  let f = rewrite f in
  let (f,nnf) = PLTLMisc.ppFormula f PLTLMisc.ranking PLTLMisc.noty in

  let _ = if !echo then print_endline (P.exportFormula f) in
  let _ = infoMesg 1 ("Parsed formula in " ^ (string_of_float ((Unix.gettimeofday()) -. initTime))) in

  let _ = infoMesg 1 ("Formula size: " ^ string_of_int (P.sizeFormula f)) in

  (* PLTL-MUP: Map the input formulae to nnf numbers *)
  let _ = initFormulaMap nnf in
  
  (* Initialise BDDs *)
  let _ = initBDD nnf in
  
  (* Check for early termination conditions *)
  (* Change for PLTL-MUP: Don't terminate early if we find something trivially
   * unsat - instead, go through the entire proof so we can minimise it *)
  let _ = 
    if !hposEX < 0 then
      begin
	infoMesg 1 "Purely Propositional";
		print_endline "Satisfiable";
		bdd_done ();
		exit 0
      end
  in

  let nBDDvars = bdd_varnum() in
  let _ = infoMesg 1 ("Number of BDD variables+clones: " ^ (string_of_int nBDDvars)) in
  (* If f ~ bdd[i] then f' ~ bdd[i+1]*)
  let pairmap = bdd_newpair() in
  let vdash = 
    let vars =
      let rec fn acc i =
	if i < 0 then acc
		else fn ((2*i+1)::acc) (pred i)
  in
		fn [] (pred (nBDDvars/2))
      in
	  bdd_makeset vars
    in
	(*	  bdd_autoreorder ~strategy:Win2ite ();*)
  let _ =
    for i = 0 to (nBDDvars/2-1) do
      if bdd_setpair pairmap (2*i) (2*i + 1) != 0 then begin
	print_endline "Error constructing pair map!";
		exit (-1)
      end
	done;
  in

  let arrayBDDdash = Array.copy !arrayBDD in
  let _ =
    for i = 0 to !nrFormulae-1 do
      arrayBDDdash.(i) <- bdd_replace !arrayBDD.(i) pairmap
    done
  in

	(* Construct the BDD representing the (restriction on the) modal relation *)

  let _ = infoMesg 1 "Creating bddR..." in
  let startRTime = Unix.gettimeofday () in

  let bddR =
    let rec fn acc i =
      if i < !lposEX then acc
	  else begin
	    (* <X g> <=> g' *)
	    let exg = !arrayBDD.(i) in
	    let g = arrayBDDdash.(!arrayDest1.(i)) in
	    let b = bdd_biimp exg g in
	    fn (b::acc) (pred i)
      end
	    in
	let l = (fn [] !hposEX) in
	(* let _ = bdd_reorder ~strategy:Win2ite () in *)
  if l = [] then
    bdd_true
      else
	bdd_bigand l
  in

  let bddRTime = (Unix.gettimeofday ()) -. startRTime in
  let _ = infoMesg 1 ("Defined bddR in " ^ (string_of_float bddRTime)) in


  (* The condition that a state must have some successor *)
  let bddSucc s =
    bdd_appex bddR (bdd_replace s pairmap) 0 vdash
	(*bdd_exist (bdd_and bddR (bdd_replace s pairmap)) vdash*)
  in

	(* The condition that each existential must have a witness*)
  let bddLC1 s =
    let sdash = bdd_replace s pairmap in
    let rs = bdd_and sdash bddR in
    let rec fn acc i =
      if i < !lposEX then acc
	  else begin
	    (* ~<X g> v exists( S(V') ^ R(V,V') ^ g' *)
	    let exist = bdd_appex arrayBDDdash.(!arrayDest1.(i)) rs 0 vdash in
	    let b = bdd_imp !arrayBDD.(i) exist in
	    fn (b::acc) (pred i)
	  end
	    in
	let l = (fn [] !hposEX) in
	if l = [] then bdd_true
	  else bdd_bigand l
	in

	(* Find the set of worlds which satisfy (g U h) *)
  let fragun rs i =
    let h = !arrayBDD.(!arrayDest1.(i)) in
    let g = !arrayBDD.(!arrayDest1.(!arrayDest2.(i))) in
    let iter = ref 0 in
    let rec fix z =
      incr iter;
	  infoMesg 3 ("Intermediate frageu: " ^ (string_of_int !iter));
	  let inner = bdd_replace z pairmap in
	  let exist = bdd_appex inner rs 0 vdash in
	  (*	  let exist = bdd_exist (bdd_and inner bddR) vdash in*)
    let znew = bdd_or h (bdd_and g exist) in
    if znew = z then z
		else fix znew
    in
	let ret = fix h in
	infoMesg 2 ("frageu: " ^ (P.exportFormula (!arrayFormula.(i))) ^ " -- " ^ string_of_int !iter);
	  ret
	in

	(* The worlds which claim to satisfy an eventuality must actually do so *)
  let bddUn s =
    let lst =
      let rs = bdd_and (bdd_replace s pairmap) bddR in
      let rec fn acc i =
	if i < !lposEX then acc
		else begin
		  if !arrayType.(!arrayDest1.(i)) = 7 (* UN *) then begin
		    infoMesg 3 ("UN " ^ (P.exportFormula !arrayFormula.(!arrayDest1.(i))));
			let eu = !arrayDest1.(i) in
			let exeu = !arrayBDD.(i) in
			let g = !arrayBDD.(!arrayDest1.(!arrayDest2.(eu))) in
			let frag = fragun rs eu in
			fn ((bdd_imp (bdd_and exeu g) frag)::acc) (pred i)
	  end
	else fn acc (pred i)
		  end
			in
		fn [] !hposEX
      in
	  if lst = [] then bdd_true
	  else bdd_bigand lst
    in


  (* Try to restrict the initial state as much as possible *)
  (* e.g. if a formula G p holds, then p must hold everywhere *)
  (* PLTL-MUP: Main global assumptions code has been moved so
   * we can use it during minimisation *)
  let initialGuess i =
    if assumeGs then 
      let gbdd = assumeGlobal i in
      let _ = bdd_fprintdot stdout gbdd in
     gbdd 
    else bdd_true
    in

  let stateBDD =
    infoMesg 1 "Starting state calculation...";
	let iter = ref 0 in

	(* Two possible ways of performing the fixpoint computation *)
	(* I believe that sequential works better than simultaneous *)
	let rec fixsequence s =
	  if preemptiveCheck && bdd_and s !arrayBDD.(nnf) = bdd_false then bdd_false
	  else begin
	    incr iter;
		infoMesg 3 ("GFP intermediate: " ^ (string_of_int !iter));
		let snew = s in
		let _ = infoMesg 2 "Succ..." in
		let snew = bdd_and snew (bddSucc snew) in
		let _ = infoMesg 2 "LC1..." in
		let snew = bdd_and snew (bddLC1 snew) in
		let _ = infoMesg 2 "UN..." in
		let snew = bdd_and snew (bddUn snew) in
		if snew = s then s
		  else fixsequence snew
		end
		in
	let rec fixsimultaneous s =
	  if preemptiveCheck && bdd_and s !arrayBDD.(nnf) = bdd_false then bdd_false
	  else begin
	    incr iter;
		infoMesg 3 ("GFP intermediate: " ^ (string_of_int !iter));
		let _ = infoMesg 2 "Succ..." in
		let succ = (bddSucc s) in
		let _ = infoMesg 2 "LC1..." in
		let lc1 = (bddLC1 s) in
		let _ = infoMesg 2 "Un..." in
		let un = (bddUn s) in
		let snew = bdd_bigand [s;succ;lc1;un] in
		if snew = s then s
		  else fixsimultaneous snew
	  end
		in
	let fix = 
	  if !simultaneous then
	    fixsimultaneous
		else
		  fixsequence
	in
	let ret = fix (initialGuess nnf) in
	infoMesg 1 ("GFP: " ^ string_of_int !iter);
	  ret
	in

  let answer = bdd_and stateBDD !arrayBDD.(nnf) in


  let elapsed = (Unix.gettimeofday()) -. startTime in
  let _ = infoMesg 1 ("Prover time elapsed: " ^ (string_of_float elapsed)) in


  if answer = bdd_false then
    let _ = print_endline "Unsatisfiable" in
    if !minimise then
      let result = minUnsat stateBDD in
      if result <> [] then
	let _ = Printf.printf "\nMinimal unsatisfiable subset:\n" in
	let _ = printMinunsat result in
	print_endline ("MUS Size: " ^ string_of_int (List.length (List.filter (fun x -> x = true) result)));
	
      else
	Printf.printf "Could not successfully minimize";
    else
      ();
  else
    print_endline "Satisfiable";

    bdd_done()
