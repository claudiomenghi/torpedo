(** A one-pass tree-tableau-based decision procedure for PLTL-satisfiability
    which blocks on ancestor core-nodes and caches unsatisfiable core-nodes.
    It is in EXPSPACE, that is it is not optimal.
    @author Florian Widmann
	@author Jimmy Thomson
 *)


module P = PLTLFormula

type formula = P.formula


open PLTLMisc
open MiscSolver


(** An instantiation of a hash table (of the standard library) for bitsets.
 *)
module GHt = Hashtbl.Make(
  struct
    type t = bitset
    let equal (bs1 : t) bs2 = compareBS bs1 bs2 = 0
    let hash (bs : t) = hashBS bs
  end
)

module IHt = Hashtbl.Make(
  struct
	type t = int
	let equal (i1: t) i2 = i1 = i2
	let hash i = i
  end
)

(** Defines the history Chn which can be seen as a partial function
    mapping U-formulae to positive ints.
    It is implemented as an array that is indexed by U-formulae
    (i.e. their integer representation shifted by an offset).
    U-formulae for which Chn is undefined are mapped to naught.
    The array has size #{U-formulae}.
 *)
type hchn = int array

(** The size of the arrays representing Chns
    (i.e. the number of U-formulae).
 *)
let sizeChn = ref (-1)

(** The greatest index of the Chns.
    It must hold indexChn = sizeChn - 1.
 *)
let indexChn = ref (-1)

(** Tests whether two Chns are equal.
    @param chn1 The first Chn.
    @param chn2 The second Chn.
    @param i The current index of the array.
    @return True iff chn1 and chn2 are equal.
 *)
let rec intern_isEqualChn (chn1 : hchn) chn2 i =
  if i >= 0 then
    if chn1.(i) = chn2.(i) then intern_isEqualChn chn1 chn2 (pred i)
    else false
  else true

let isEqualChn (chn1 : hchn) chn2 = intern_isEqualChn chn1 chn2 !indexChn

(** Defines a new value for a U-formula in a Chn.
    The old value is overridden.
    @param chn A Chn.
    @param f The U-formula that is to be mapped to a new value in chn.
    @param n The new value that is assigned to f in chn.
    @raise Invalid_argument If f is not a U-formula.
 *)
let setChn (chn : hchn) f n = chn.(f - !lposUN) <- n

(** Gets a value in a Chn for a U-formula.
    @param chn A Chn.
    @param f A U-formula.
    @return The value of f in chn.
    @raise Invalid_argument If f is not a U-formula.
 *)
let getChn (chn : hchn) f = chn.(f - !lposUN)


(** Constructs the Chn for the X-rule.
    @param fs A bitset containing the formulae of the new core-node.
    @param lvl The level of the new core-node.
    @param chn The old Chn.
    @return The resulting Chn for the new core-node.
 *)
let newChn fs lvl chn = 
  let nchn = Array.make !sizeChn (-1) in
  let offset = !lposUN in
  for i = offset to !hposUN do
    if memBS fs i then
      let ioffs = i - offset in
      let inhlvl = chn.(ioffs) in
      let nlvl = if inhlvl >= 0 then inhlvl else lvl in
      nchn.(ioffs) <- nlvl
    else ()
  done;
  nchn




(** An instantiation of a hash table (of the standard library) for bitsets.
 *)
module CHt = Hashtbl.Make(
  struct
    type t = bitset * hchn
    let equal ((bs1, chn1) : t) (bs2, chn2) =
      compareBS bs1 bs2 = 0 && isEqualChn chn1 chn2
    let hash ((bs, _) : t) = hashBS bs
  end
 )


(** Defines the variable Uev which can be seen as a partial function
    mapping U-formulae to positive ints.
    It is implemented as an array that is indexed by U-formula
    (i.e. their integer representation shifted by an offset).
    U-formulae for which Uev is undefined are mapped to naught.
    The array has size #{U-formulae}.
 *)
type vuev = int array

(** The size of the arrays representing Uevs
    (i.e. the number of U-formulae).
 *)
let sizeUev = ref (-1)

(** The greatest index of the Uevs.
    It must hold indexUev = sizeUev - 1.
 *)
let indexUev = ref (-1)
    
(** Tests whether a Uev is undefined for every formula.
    @param uev A Uev.
    @param i The current index of the array.
    @return True iff uev is undefined everywhere.
 *)
let rec intern_is_undef uev i =
  if i >= 0 then
    if uev.(i) = (-1) then intern_is_undef uev (pred i)
    else false
  else true

let is_undefinedUev uev = intern_is_undef uev !indexUev

(** Defines a new value for a U-formula in a Uev.
    The old value is overridden.
    @param uev A Uev.
    @param f The U-formula that is to be mapped to a new value in uev.
    @param n The new value that is assigned to f in uev.
    @raise Invalid_argument If f is not a U-formula.
 *)
let setUev (uev : vuev) f n = uev.(f - !lposUN) <- n

(** Gets a value in a Uev for a U-formula.
    @param uev A Uev.
    @param f A U-formula.
    @return The value of f in uev.
    @raise Invalid_argument If f is not a U-formula.
 *)
let getUev (uev : vuev) f = uev.(f - !lposUN)

(** This functions "intersects" two Uevs.
    The result is returned in the first Uev.
    @param uev1 The first Uev.
    @param uev2 The second Uev.
    @param i The current index of the array.
    @return A Uev that is defined exactly for the formulae that are defined in uev1 and uev2.
    Each of these formulae is mapped to the smaller value of its mappings in uev1 and uev2.
 *)
let rec intern_minUev (uev1 : vuev) uev2 i =
  if i >= 0 then
    let h1 = uev1.(i) in
    let h2 = uev2.(i) in
    if h2 < h1 then uev1.(i) <- h2 else ();
    intern_minUev uev1 uev2 (pred i)
  else uev1

let minUev (uev1 : vuev) uev2 = intern_minUev uev1 uev2 !indexUev

(** This function checks whether there is a bad loop in the tableau,
    i.e. it checks whether there is an U-formula
    such that this formula is defined in the Uev
    and has a value greater than or equal to the given bound.
    @param n A bound.
    @param uev A Uev.
    @return Some f iff an U-formula f is defined in uev with uev(f) >= n.
	        None otherwise
 *)
let findSubloop (n : int) uev =
  let j = ref !indexUev in
  let res = ref None in
  while !res = None && !j >= 0 do
    if uev.(!j) >= n then res := Some (!j + !lposUN) else decr j
  done;
  !res


(** This function calculates the values of AU-formulae for the Uev of an EX-node.
    @param uev An Uev that is already correctly defined for the EU-formulae
    and not defined for any AU-formula.
    @param n The maximal depth of all virtual successors of the EX-node.
    @param uevl The list of all Uevs of the not blocked children of the EX-node.
    @param fs A bitset of formulae which contains all EU- and AU-formulae
    that may potentially be defined.
    @param chn A Chn.
 *)
let mkUev lvl fs chn = 
  let uev = Array.make !sizeUev (-1) in
  let offset = !lposUN in
  for i = !lposUN to !hposUN do
    if memBS fs i then
      let ioffs = i - offset in
	  let n = chn.(ioffs) in
		if n >= 0 && n <= lvl then uev.(ioffs) <- lvl
  done;
  uev

(** 
	Pretty-printing of bitsets, gives a comma seperated list of formulae in the bitset
*)


let outputBS oc bs =
  output_string oc ("{");
  for i = 0 to !nrFormulae -1 do
	if memBS bs i then
	  begin
		output_string oc (P.exportFormula (!arrayFormula.(i)));
		output_string oc (", ");
	  end;
  done;
  output_string oc ("}")

let printBS bs =
  outputBS stdout bs


let breakAnds f = 
  let rec intern acc f =
	match f with
	  | P.AND (f1,f2) -> intern (intern acc f1) f2
	  | _ ->
		  if List.mem f acc then acc
		  else f::acc
  in intern [] f

let compareF = P.generateCompare P.aRanking

let isBlamed bs f =
  let nnf = P.nnf f in
  let rec reduce = function
	| P.AND(f1,f2) -> P.AND(reduce f1,reduce f2)
	| P.OR (f1,f2) -> P.OR (reduce f1,reduce f2)
	| P.BF (f1,f2) -> P.BF (reduce f1,reduce f2)
	| P.UN (f1,f2) -> P.UN (reduce f1,reduce f2)
	| P.AW f1 -> P.BF (P.FALSE, reduce (P.nnf (P.NOT f1)))
	| P.EV f1 -> P.UN (P.TRUE , reduce f1)
	| x -> x
  in
  let nnf = reduce nnf in
  let rec causes f g =
	if compareF f g = 0 then true
	else
	match f with
	  | P.AND (f1,f2) -> causes f1 g || causes f2 g
	  | P.BF (f1,f2) -> 
		  causes (P.X f) g
		  || causes (P.nnf (P.NOT f2)) g
	  | P.AW f1 ->
		  causes f1 g
		  || causes (P.nnf (P.BF (P.FALSE, P.NOT f1))) g
	  | _ -> false
  in
  let rec intern i =
	if i < 0 then false
	else if memBS bs i && causes nnf (!arrayFormula.(i)) then true
	else intern (pred i)
  in
	intern !nrFormulae

(** Pretty print a bitset, replacing the internal formulae with their original
	representations from f
 *)
let prettyPrintBS bs f =
  let flist = breakAnds f in
  let blamed = List.filter (isBlamed bs) flist in
  let printfn ff =
	print_string ((P.exportFormula ff) ^", ")
  in
	print_string "{";
	List.iter printfn blamed;
	print_endline"}"


(** 
	Add to pset the formulae causing the contradiction.
	If p is -1, then the contradiction was caused by a combination of formulae
	but not in any one formula (i.e. f = p|q, ~f = ~p & ~q, fsetc = {~p,~q})
	In that case, some complete set of formulae resulting in ~f are found and added to pset
	Otherwise p is added to pset
*)
let getContradiction pset fsetc f p =
  emptyBS pset;
  if p < 0 then
	let _ = insertFormulaNS pset f in
	let fn q = addBSNoChk pset q in
	  List.iter fn (getAllSubF fsetc !arrayNeg.(f))
  else begin
	addBSNoChk pset p;
	  addBSNoChk pset !arrayNeg.(p)
	end;
  pset





(* (id, fs, [children], state) *)
type pseudomodel = int * (int * bitset * (int list) * bool ) IHt.t

type satRet = vuev * pseudomodel

type pltlSat = Closed of bitset | Open of satRet

(** Gets a tableau node (i.e. its formula set and histories)
    and builds the sub-tableau rooted at the given node.
    @param fset A bitset containing all formulae in fsetc
    which still might have to be decomposed.
    @param fsetc A bitset of formulae.
    @param hc The history HCore of the given node.
    @param chn The history Chn of the given node.
    @param dp The depth of the given node in the tableau.
    @param cores The depth of the node in terms of core nodes
    Both must be greater or equal than one.
    @param cache A hash table mapping (open core-node)-chn pairs
    to their corresponding uevs. It can only be used for core-nodes
    which have the same parent core-node.
    @return Closed set if the node is marked,
    Open uev otherwise where uev is the Uev of the node.
 *)

let rec intern_isSat fset fsetc hc chn dp cores unsats =
  let pf = getPFinclEX fset in
  let myid = !nodecount in
	if pf >= 0 then
      let pftype = !arrayType.(pf) in
		match pftype with
		  | 5 (* OR *)
		  | 7 (* UN *)
			-> 
			  remBS fset pf;
			  let lvl = if pftype = 5 then (-1) else getChn chn pf in
			  let f1 = !arrayDest1.(pf) in
			  let f2 = !arrayDest2.(pf) in
				if containsFormula fsetc f1 || (lvl = (-1) && containsFormula fsetc f2) then
				  if lvl = (-1) then intern_isSat fset fsetc hc chn dp cores unsats
				  else begin
					setChn chn pf (-1);
					let res = intern_isSat fset fsetc hc chn dp cores unsats in
					  setChn chn pf lvl;
					  res
				  end
				else begin
				  incr nodecount;
				  let fset2 = copyBS fset in
				  let fsetc2 = copyBS fsetc in
				  let cntr = insertFormulaBlame fset fsetc f1 in
				  let mrk1 =
					match cntr with
					  | None ->
						  if lvl = (-1) then intern_isSat fset fsetc hc chn (succ dp) cores unsats
						  else begin
							setChn chn pf (-1);
							let res = intern_isSat fset fsetc hc chn (succ dp) cores unsats in
							  setChn chn pf lvl;
							  res
						  end
					  | Some p ->
						  if dp > !pathlength then pathlength := dp;
						  Closed (getContradiction fset fsetc f1 p)
				  in
				  let rbranch () =
					blitBS fsetc2 fsetc;
					let f1neg =
					  if !arrayNeg.(f1) >= 0 then
						begin
						  (*incr sembranchs;*)
						  !arrayNeg.(f1)
						end
					  else !bstrue
					in
					let cntr = insertFormulaBlame fset2 fsetc2 f1neg in
					let mrk2 =
					  match cntr with
						| None ->
							begin
							  let cntr = insertFormulaBlame fset2 fsetc2 f2 in
								match cntr with
								  | None -> intern_isSat fset2 fsetc2 hc chn (succ dp) cores unsats
								  | Some p -> 
									  if dp > !pathlength then pathlength := dp;
									  let ps = (getContradiction fset2 fsetc2 f2 p) in
										forceFormula ps f2;
										Closed ps
							end
						| Some p ->
							if dp > !pathlength then pathlength := dp;
							Closed (getContradiction fset2 fsetc2 f2 p)
					in
					  match (mrk1, mrk2) with
						| (Closed p1 , Closed p2) ->
							(* If p1 was closed for a relevant reason (and thus the second branch is attempted)
							   but p2 was not, then what should the result be?
							*)
							(* If p2 is effected by f2 at all, then treat this as relevant
							   Otherwise blame the right path unchanged
							   -- This doesn't seem right on further thought
							   -- If the left path can work out with different earlier decisions then it must be
							   -- considered, even if the right path fails regardless
							   ++ Instead, remove f1 from p1 and add pf to it, and do not change p2?
							   --- Wait, it was right the first time. If A v B has A relevant and B irrelevant,
							   --- then the problem with the B branch is more general so just use that
							*)
							if containsAnySubFormula p2 f2 || 
							  (not (f1neg = !bstrue) && containsAnySubFormula p2 f1neg) then begin
								removeFormula p1 f1;
								removeFormula p2 f2;
								removeFormula p2 f1neg;
								unionBS p2 p1;
								addBSNoChk p2 pf
							  end;
							Closed p2
						| (Open (uev1,(nde1,mdl1)), Open (uev2,(nde2,mdl2))) -> 
							let uev = minUev uev1 uev2 in (* TODO: combine partial pseudomodels*)
							  (* (id, fs, [children], state) *)
							let mdl = mdl1 in
							let mergef k v = IHt.add mdl k v in
							  IHt.iter mergef mdl2;
							  IHt.add mdl myid (myid, copyBS fsetc, [nde1;nde2], false);
							  Open (uev, (myid, mdl))
						| (Open _, Closed p) -> 
							mrk1
						| (_, Open _) -> mrk2 
				  in
					match mrk1 with
					  | Open (uev1,_) when is_undefinedUev uev1 -> mrk1
					  |	Closed p ->
						  if subsetBS p fsetc2 then begin
							Closed p
						  end
						  else
							rbranch ()
					  | _ ->
						  rbranch ()
				end
		  | _ -> (* must be 4 = EX *)
			  incr nodecount;
			  let state = copyBS fsetc in (* A copy of the fully-expanded state *)
			  let hcfsetc = makeBS () in
			  let cntr = mkXSetBlame fsetc fset hcfsetc in
				match cntr with
				  | None ->
					  begin
						match 				
						  try
							let ps = GHt.find unsats hcfsetc in
							  blitBS ps state;
							  Some state
						  with Not_found -> None
						with
						  | Some unsat -> Closed unsat
						  | None ->
							  let (j,jid) =
								try
								  GHt.find hc hcfsetc
								with Not_found -> (-1, -1)
							  in
								if j >= 0 then
								  let uev = mkUev j hcfsetc chn in
								  let mdl = IHt.create 10 in
									IHt.add mdl myid (myid, copyBS state, [jid], true);
									if dp > !pathlength then pathlength := dp;
									Open (uev,(myid, mdl))
								else
								  let nchn = newChn hcfsetc cores chn in
									blitBS hcfsetc fsetc;
									GHt.add hc hcfsetc (cores,myid);
									let res = intern_isSat fset fsetc hc nchn (succ dp) (succ cores) unsats in
									  GHt.remove hc hcfsetc;
									  match res with
										| Open (suev,(sid, smdl)) ->
											begin
											  match findSubloop cores suev with
												| Some f ->
													let axs = fset in
													  emptyBS axs;
													  for i = !lposEX to !hposEX do
														if memBS state i then
														  addBSNoChk axs i
													  done;
													  blitBS axs state; (* Don't need state any more, and we can guarantee that it won't be used again *)
													  GHt.add unsats hcfsetc state;
													  Closed axs
												|  _ ->
													 let mdl = smdl in
													   IHt.add mdl myid (myid, copyBS state, [sid], true);
													   Open (suev,(myid, mdl)) 
											end
										| Closed pset ->
											blitBS pset fsetc;
											let retset = propagateBlame fsetc pset state in
											  (*addUnsat retset;*)
											  blitBS retset state;
											  GHt.add unsats hcfsetc state;
											  Closed retset
					  end
				  | Some (p,axp) ->
					  (* If the set of Xs is immediately unsatisfiable, work it out *)
					  if dp > !pathlength then pathlength := dp;

					  (* The set of AX formulae is inconsistent: go back until they change*)
					  let pset = getContradiction fset hcfsetc (!arrayDest1.(axp)) p in

						emptyBS hcfsetc;
						addBSNoChk hcfsetc axp;
						let retset = propagateBlame pset hcfsetc state in
						  (*addUnsat retset;*)
						  Closed retset
							
		else
		  (* No X formulae, so we construct a new state by adding X True
			 This state is trivially satisfiable (No formulae progress
			 from this state or they would be X formulae) so return sat
		  *)
		  let mdl = IHt.create 10 in
			IHt.add mdl (-1) (-1, makeBS(), [-1], true);
			IHt.add mdl myid (myid, copyBS fsetc, [-1], true);
		  Open (Array.make !sizeUev (-1), (myid,mdl))



let printPseudoModel oc mdl root =
  output_string oc "digraph G {\n";
  let printnode k (_,fs,children,state) =
	output_string oc ("n"^(string_of_int k)^" [label='");
	for i = !hposEX +2 to !nrFormulae do
	  if memBS fs i then
		let _ = 
		  output_string oc (P.exportFormula !arrayFormula.(i)) in
		  output_string oc ", "
	done;
	output_string oc ("']\n");
	let printedge e =
	  output_string oc ("n"^(string_of_int k)^" -> n" ^ (string_of_int e) ^ " [style=" ^ (if state then "solid" else "dotted") ^ "]\n")
	in
	  List.iter printedge children
  in
	IHt.iter printnode mdl;
	output_string oc ("start [style=invis]\nstart -> n" ^ (string_of_int root));
	output_string oc "\n}"



(** A one-pass tree-tableau-based decision procedure for PLTL-satisfiability
    which blocks on ancestor core-nodes and caches unsatisfiable core-nodes.
    It is in EXPSPACE, that is it is not optimal.
    @param verbose An optional switch which determines
    whether the procedure shall print some information on the standard output.
    The default is false.
    @param f The input formula that is tested for satisfiability.
    @return True if f is satisfiable, false otherwise.
 *)
let isSat ?(verbose = false) ?(model = None) f = 
  let start = if verbose then Unix.gettimeofday () else 0. in
  let (nnf, fi) = ppFormula f rankingNoAnd notyNoAnd in
  sizeUev := (!hposUN - !lposUN + 1);
  indexUev := pred !sizeUev;
  sizeChn := !sizeUev;
  indexChn := pred !sizeChn;
  let fset = makeBS () in
  let fsetc = makeBS () in
  let cntr = insertFormulaBlame fset fsetc fi in
  let sat =
    match cntr with
	  | Some p ->
		  if verbose then begin
			print_endline "Unsatisfiable subset:";
			let pset = getContradiction fset fsetc fi p in
			prettyPrintBS pset f
		  end;
		  false
	  | None ->
		  let hc = (GHt.create 1024 : (int*int) GHt.t) in
		  let unsats = (GHt.create 64 : bitset GHt.t) in
		  let chn = Array.make !sizeChn (-1) in
		  let ret = match intern_isSat fset fsetc hc chn 1 1 unsats
		  with
			|	Open (_, (id, mdl)) -> 
				  (match model with 
					 | Some file -> 
						 let outfile = open_out file in
						   printPseudoModel outfile mdl id;
						   close_out outfile
					 | None -> ()
				  ); true
			|	Closed ps ->
				  if verbose then begin
					print_endline "Unsatisfiable subset:";
					(*printBS ps;*)
					prettyPrintBS ps f
				  end;
				  false
		  in
			ret
  in
  if verbose then begin
    let stop = Unix.gettimeofday () in
    print_newline ();
    print_endline ("Input formula: " ^ (P.exportFormula f));
    print_endline ("Size: " ^ (string_of_int (P.sizeFormula f)));
    print_endline ("Negation Normal Form: " ^ (P.exportFormula nnf));
    print_endline ("Size: " ^ (string_of_int (P.sizeFormula nnf)));
    print_endline ("Result: Formula is " ^ (if not sat then "not " else "") ^ "satisfiable.");
    print_endline ("Time: " ^ (string_of_float (stop -. start)));
	print_endline ("Number of formulae: " ^(string_of_int !nrFormulae));
    print_endline ("Generated nodes: " ^ (string_of_int !nodecount));
    print_endline ("Longest path: " ^ (string_of_int !pathlength));
(*	print_endline ("SAT cache hits: " ^ (string_of_int !cachehits));
	print_endline ("Branches skipped by backjumping: " ^ (string_of_int !backjumps));
	print_endline ("Maximum size of unsats: " ^(string_of_int !maxUnsatSize));
	print_endline ("Size of learned sats: " ^ (string_of_int (List.length !sats)));
	print_endline ("Number of times semantic branching occured: " ^ (string_of_int !sembranchs)); *)
(*	printUnsats ();*)
    print_newline ()
  end else ();
  sat


(* getNewID() to assign names to nodes XXXXXXXXXXXX nodecount will do
   Keep a map id -> (formulae, children, and/or)
   -- no; just a tree (formulae, children, and/or)
   --- no, need the id for when it was cached
   ---- How do looping nodes track their children which aren't assigned numbers yet?
   ----- Assign IDs in prefix order, assign entries in the map in postfix order. 
   join nodes together in postfix order according to the connective
*)
