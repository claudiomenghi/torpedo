#!/usr/bin/env python3

import os
import re

# Translator from TRP to PLTL syntax
# Timothy Sergeant, May 2013
#
# Responsible for two things: Translating the keywords used by TRP ('next', 'always', ...) into
# symbols used by PLTL, and splitting the single large formula into its subformulae (by splitting
# every & which is not nested within the syntax tree)
#
# Accepts a list of files to be processed from standard in - this is intended to be used on
# the output of ls
#
# This was pieced together over the course of an afternoon, and has barely been touched since.

def tokenise(text):
    return list(filter(lambda x: x, text.replace("(", " ( ").replace(")", " ) ").split(" ")))


def recursive_split(tokens, start, end):
    depth = 0
    current = start
    if end <= start:
        return []
    if tokens[current] != "(":
        return [tokens[start:end]]
    while True:
        if current == end:
            #print("Reached end without hitting toplevel -- mismatched brackets?")
            return [tokens[start:end]]
        if tokens[current] == "(":
            depth += 1
        elif tokens[current] == ")":
            depth -= 1
        current += 1
        if depth == 0:
            break

    #print("Hit toplevel at token {}".format(current))

    if current < end and tokens[current] == "&":
        #print("Hit an and! Recursing!")
        res_left = recursive_split(tokens, start + 1, current - 1)
        if not res_left:
            res_left = []
        res_right = recursive_split(tokens, current+1, end)
        if not res_right:
            res_right = []

        res_left.extend(res_right)

        return res_left
    else:
        return [tokens[start:end]]


def keywordTranslate(text):
    text = re.sub("not", "~", text)
    text = re.sub("always", "G ", text)
    text = re.sub("sometime", "F ", text)
    text = re.sub("next", "X ", text)
    text = re.sub("until", "U", text)
    text = re.sub("\->", "=>", text)
    return text

def keywordTranslateFile(infile, outfile):
    inf = open(infile, 'r')
    outf = open(outfile, 'w')

    for line in inf:
        ltlline = keywordTranslate(line).strip()
        if ltlline[-1] == '&':
            ltlline = ltlline[:-2].strip()
        outf.write(ltlline + "\n")

    inf.close()
    outf.close()


def doTranslate(text):
    text = keywordTranslate(text)

    tokens = tokenise(text)
    split = recursive_split(tokens, 0, len(tokens))

    return list(map(lambda x: " ".join(x), split))

def processFile(filename):
    print("Processing {}".format(filename))

    f = open(filename)
    ftext = f.read()
    f.close()

    result = doTranslate(ftext)

    outfile = "pltl/" + os.path.splitext(os.path.basename(filename))[0] + ".pltl"
    print(outfile)
    o = open(outfile, 'w')
    for form in result:
        o.write(form + "\n")
    o.close()

def main():
    filename = input()
    while filename:
        try:
            processFile(filename)
            filename = input()

        except EOFError:
            break



if __name__ == "__main__":
    main()
