#!/usr/bin/env python3

import datetime
import os
import re
from subprocess import Popen
import sys
from cases import TEST_CASES, ORDERED_FAMILIES
from translator import keywordTranslateFile


# Python test harness for PLTL-MUP
# Timothy Sergeant, May 2013
#
# Executes PLTL-MUP and 4 other similar programs over a set of benchmark test cases.
# Cases are defined in cases.py
# Most of the heavy work is performed in the base TestSuite class.
# Each individual prover then adds its own run and log code.
# It isn't easy to keep this clean, since a lot of log processing needs to be done


# Config!
# These values can be changed according to how your machine is configured.

# Runlim is available at http://fmv.jku.at/runlim/
RUNLIM = "./runlim"
TIME_LIMIT = 600  #Default: 10 minutes
MEMORY_LIMIT = 6144 #Default: 6GB
LOGFOLDER = "log_test"

PLTL_TEST_FOLDER = "tests/pltl"
TRP_TEST_FOLDER = "tests/trp"

# I symlink these in from their actual build directories.
PLTL_MUP_EXECUTABLE = "./pltlmup"
PLTL_BDD_EXECUTABLE = "./pltlbdd"
PROCMINE_EXECUTABLE = "./inconanalysis"
TRPUC_EXECUTABLE = "./trp"


def get_regex_match(regex, s, f, default = None):
    """
    Helper function for parsing log files
    """
    match = regex.match(s)
    if match:
        return f(match.group(1))

    return default

def get_short_status(long_status):
    if long_status == 'ok':
        return 'p'
    elif long_status == 'out of time':
        return 't'
    elif long_status == 'out of memory':
        return 'm'

class TestSuite(object):
    """
    Base class for a test suite. Gives basics for logging and running every test case.
    """
    def __init__(self):
        self.logfolder = "{}/{}__{}".format(LOGFOLDER, datetime.datetime.now().strftime("%d_%m__%H_%M"), self.testname)

        os.mkdir(self.logfolder)

        self.resultfile = open(self.logfolder + "_results.csv", 'w')

        self.writeResultHeader()

    def finish(self):
        self.resultfile.close()

    def runtest(self, testname):
        raise NotImplementedError()

    def isSuccessfulStatus(self, status):
        """
        Indicates whether a status code should be considered a success, or added to the failure count
        and used for skipping later tests. Allows the skipping behaviour to be modified.
        """
        return status == "p"

    def getLogfileName(self, testname):
        return "{}/{}.log".format(self.logfolder, testname)

    def writeResult(self, results):
        results = map(str, results)
        self.resultfile.write(",".join(results) + "\n")
        self.resultfile.flush()

    def writeResultHeader(self):
        raise NotImplementedError()

    def run(self, families = None):
        """
        Calls the runtest method for each test case. Keeps track of failures,
        and does basic logging to the console.
        """
        if not families:
            families = sorted(TEST_CASES.keys())

        for family in families:
            print("Test family: {}".format(family))
            failed = 0

            ordered_family = family in ORDERED_FAMILIES

            for test in TEST_CASES[family]:

                print("Test case: {}".format(test))

                if ordered_family and failed >= 2:
                    print("Skipping test")
                    self.writeResult([test, "s"])
                    continue
                else:
                    result, time = self.runtest(test)
                    if self.isSuccessfulStatus(result):
                        print("Success: {}, {: .3f}".format(result, time))
                    else:
                        print("Failed: {}".format(result))
                        failed += 1



def run_bdd_test(execname, logfile, testfilename, timelimit = TIME_LIMIT):
    """
    Helper method to run a pltlbdd-style executable (pltlbdd and PLTL-MUP). These
    require the test case to be given as standard input.
    """
    testfile = open(testfilename)
    p = Popen(
        [RUNLIM, "--time-limit={}".format(int(timelimit)), "--space-limit={}".format(MEMORY_LIMIT), execname],
        stdin=testfile, stdout=logfile, stderr=logfile)
    p.wait()
    testfile.close()
    logfile.close()

class PLTLMUPTestSuite(TestSuite):
    def __init__(self):
        self.testname = "pltlmup"
        self.execname = PLTL_MUP_EXECUTABLE
        super().__init__()

    def writeResultHeader(self):
        self.writeResult(["Name", "Status", "Size", "Formula Count", "MUS Size", "Prover Time", "Minimisation Time"])



    def runtest(self, testname):
        logfilename = self.getLogfileName(testname)
        logfile = open(logfilename, 'w')



        run_bdd_test(self.execname, logfile, "{}/{}.pltl".format(PLTL_TEST_FOLDER, testname))
        # Python does not allow a file to be written and then read without being closed and reopened.
        logfile = open(logfilename, 'r')

        # This method for extracting data from log files is inelegant, but works.
        re_formula_size = re.compile(r'Formula size: (\d+)')
        re_formula_count = re.compile(r'Formula count: (\d+)')
        re_mus_size = re.compile(r'MUS Size: (\d+)')
        re_status = re.compile(r'\[runlim\] status:\t\t(.*)')
        re_prover_time = re.compile(r'Prover time elapsed: ([0-9e\-\.]+)')
        re_min_time = re.compile(r'Minimisation time elapsed: ([0-9e\-\.]+)')
        re_error = re.compile(r'^Fatal error: (.*)')

        formula_size = 0
        formula_count = 0
        mus_size = 0
        status = "?"
        prover_time = 0
        min_time = 0
        error = False

        for line in logfile:
            formula_size = get_regex_match(re_formula_size, line, int, formula_size)
            mus_size = get_regex_match(re_mus_size, line, int, mus_size)
            formula_count = get_regex_match(re_formula_count, line, int, formula_count)
            status = get_regex_match(re_status, line, get_short_status, status)
            prover_time = get_regex_match(re_prover_time, line, float, prover_time)
            min_time = get_regex_match(re_min_time, line, float, min_time)
            error = get_regex_match(re_error, line, lambda x: x, error)

        if error:
            status = "e"

        self.writeResult([testname, status, formula_size, formula_count, mus_size, prover_time, min_time])
        return status, (prover_time + min_time)

class PLTLBDDTestSuite(TestSuite):
    def __init__(self):
        self.testname = "pltlbdd"
        self.execname = PLTL_BDD_EXECUTABLE

        super().__init__()

    def writeResultHeader(self):
        self.writeResult(["Name", "Status", "Time"])

    def runtest(self, testname):
        logfilename = self.getLogfileName(testname)
        logfile = open(logfilename, 'w')

        run_bdd_test(self.execname, logfile, "{}/{}.pltl".format(PLTL_TEST_FOLDER, testname))
        logfile = open(logfilename, 'r')

        status = "?"
        time = 0
        error = False

        re_status = re.compile(r'\[runlim\] status:\t\t(.*)')
        re_time = re.compile(r'Time elapsed: ([0-9\.]+)')
        re_error = re.compile(r'^Fatal error: (.*)')

        for line in logfile:
            status = get_regex_match(re_status, line, get_short_status, status)
            time = get_regex_match(re_time, line, float, time)
            error = get_regex_match(re_error, line, lambda x: x, error)

        if error:
            status = "e"

        self.writeResult([testname, status, time])

        return status, time

class ProcmineTestSuite(TestSuite):
    def __init__(self):
        self.testname = "procmine"
        self.execname = PROCMINE_EXECUTABLE
        super().__init__()

    def writeResultHeader(self):
        self.writeResult(["Name", "Status", "MUS Size", "Prover Time", "Min Time"])

    def runtest(self, testname):
        # Procmine requires the input to be given on a single line from a file called "constraints.pltl"
        testfile = open("{}/{}.pltl".format(PLTL_TEST_FOLDER, testname))
        constraints = open("constraints.pltl", 'w')
        lines = []
        for line in testfile:
            lines.append("(" + line.strip() + ")")
        constraints.write(" & ".join(lines))
        testfile.close()
        constraints.close()

        logfilename = self.getLogfileName(testname)

        logfile = open(logfilename, 'w')
        p = Popen(["./runlim", "--time-limit={}".format(TIME_LIMIT), "--space-limit={}".format(MEMORY_LIMIT), self.execname, "2", "1"],
            stdout=logfile, stderr=logfile)

        p.wait()
        logfile.close()

        logfile = open(logfilename, 'r')
        re_mus_size = re.compile(r'(.*) is the root cause')
        re_status = re.compile(r'\[runlim\] status:\t\t(.*)')
        re_prover_time = re.compile(r'Time: ([0-9e\-\.]+)')
        re_min_time = re.compile(r'Time used: ([0-9e\-\.]+) seconds')
        re_error = re.compile(r'^Fatal error: (.*)')


        mus_size = 0
        status = "?"
        prover_time = 0
        min_time = 0
        error = False

        for line in logfile:
            status = get_regex_match(re_status, line, get_short_status, status)
            prover_time = get_regex_match(re_prover_time, line, float, prover_time)
            min_time = get_regex_match(re_min_time, line, float, min_time)
            mus_size = get_regex_match(re_mus_size, line, lambda x: mus_size + 1, mus_size)
            error = get_regex_match(re_error, line, lambda x: x, error)

        self.writeResult([testname, status, mus_size, prover_time, min_time])
        return status, prover_time + min_time

class TRPUCTestSuite(TestSuite):
    def __init__(self):
        self.testname = "trpuc"
        self.execname = TRPUC_EXECUTABLE
        super().__init__()

    def writeResultHeader(self):
        self.writeResult(["Name", "Status", "Time"])

    def runtrp(self, testname):
        logfilename = self.getLogfileName(testname)
        logfile = open(logfilename, 'w')

        testfile = "{}/{}.trp".format(TRP_TEST_FOLDER, testname)
        corefile = "{}/{}_core.trp".format(self.logfolder, testname)

        # These command line arguments define the input syntax, search strategy, what type of core should be extracted
        # and where the result should be written to
        p = Popen(["./runlim", "--time-limit={}".format(TIME_LIMIT), "--space-limit={}".format(MEMORY_LIMIT),
                   self.execname, "-f", "ltl", "-s", "BFS", "-u", "simple", "-g", "ltl", "-w", corefile, testfile],
            stdout=logfile, stderr=logfile)

        p.wait()

        logfile.close()
        logfile = open(logfilename)

        re_status = re.compile(r'\[runlim\] status:\t\t(.*)')
        re_time = re.compile(r'\[runlim\] time:\t\t\t([0-9\.]+) seconds')

        status = "?"
        time = 0

        for line in logfile:
            status = get_regex_match(re_status, line, get_short_status, status)
            time = get_regex_match(re_time, line, float, time)

        return [testname, status, time]

    def runtest(self, testname):

        result = self.runtrp(testname)

        self.writeResult(result)
        return result[1], result[2]

class HybridTestSuite(TRPUCTestSuite):
    """
    This class runs the two tests separately instead of using hybrid.py for two
    reasons: It was initially written before Hybrid.py, and it makes logging
    slightly easier.

    We extend TRPUCTestSuite so we can use the runtrp method
    """
    def __init__(self):
        self.testname = "hybrid"
        self.execname = TRPUC_EXECUTABLE

        TestSuite.__init__(self)

    def writeResultHeader(self):
        self.writeResult(["Name", "TRP Status", "TRP Time", "TRP Size", "PLTL-MUP Status", "PLTL-MUP Prover Time",
                          "PLTL-MUP Min Time", "PLTL-MUP Size"])

    def runmup(self, testname, timelimit):
        trpcore = "{}/{}_core.trp".format(self.logfolder, testname)
        ltlcore = "{}/{}_core.pltl".format(self.logfolder, testname)
        # The output syntax of TRP++UC needs to be translated into the input syntax of PLTL-MUP
        keywordTranslateFile(trpcore, ltlcore)
        logfilename = "{}/{}.mup.log".format(self.logfolder, testname)

        logfile = open(logfilename, 'w')

        run_bdd_test(self.execname, logfile, "{}/{}_core.pltl".format(self.logfolder, testname), timelimit)
        logfile = open(logfilename, 'r')

        re_trp_size = re.compile(r'Formula count: (\d+)')
        re_mus_size = re.compile(r'MUS Size: (\d+)')
        re_status = re.compile(r'\[runlim\] status:\t\t(.*)')
        re_prover_time = re.compile(r'Prover time elapsed: ([0-9e\-\.]+)')
        re_min_time = re.compile(r'Minimisation time elapsed: ([0-9e\-\.]+)')

        trp_size = 0
        mus_size = 0
        status = "?"
        prover_time = 0
        min_time = 0

        for line in logfile:
            trp_size = get_regex_match(re_trp_size, line, int, trp_size)
            mus_size = get_regex_match(re_mus_size, line, int, mus_size)
            status = get_regex_match(re_status, line, get_short_status, status)
            prover_time = get_regex_match(re_prover_time, line, float, prover_time)
            min_time = get_regex_match(re_min_time, line, float, min_time)

        return [trp_size, status, prover_time, min_time, mus_size]

    def isSuccessfulStatus(self, status):
        """
        A file should only be skipped if TRP++UC fails. I've found that PLTL-MUP's performance
        varies a lot between test cases when sent through TRP++UC first
        """
        return status == "p" or status.startswith("mup-")


    def runtest(self, testname):
        self.execname = TRPUC_EXECUTABLE
        trp_result = self.runtrp(testname)

        if trp_result[1] == 'p':
            print("TRP Successful in {: .3f}".format(trp_result[2]))
            self.execname = PLTL_MUP_EXECUTABLE
            mup_result = self.runmup(testname, TIME_LIMIT - trp_result[2])
            fullresult = trp_result + mup_result
            self.writeResult(fullresult)

            # We judge whether to keep going based on the TRP status - not on the MUP status
            return "mup-" + fullresult[4], fullresult[2] + fullresult[5] + fullresult[6]

        else:
            self.writeResult(trp_result)
            return trp_result[1], trp_result[2]


TESTS = {
    'procmine':ProcmineTestSuite,
    'pltlmup': PLTLMUPTestSuite,
    'pltlbdd': PLTLBDDTestSuite,
    'trpuc': TRPUCTestSuite,
    'hybrid': HybridTestSuite,
}

def main():
    """
    Usage: python runtest.py [testname] [time_limit]
    """
    args = sys.argv
    ts = None

    if len(args) >= 2:
        testname = args[1]
        if testname in TESTS:
            ts = TESTS[testname]()
        else:
            print("{} is not a valid test. Available options: {}".format(testname, ", ".join(TESTS.keys())))
            sys.exit(1)
    if not ts:
        ts = PLTLMUPTestSuite()

    if len(args) >= 3:
        try:
            global TIME_LIMIT
            TIME_LIMIT = int(args[2])
        except ValueError:
            print("Could not parse an int from {}".format(args[2]))
            sys.exit(1)



    ts.run()
    ts.finish()

if __name__ == "__main__":
    main()
